document.addEventListener('DOMContentLoaded', function() {
    var notificationsModal = document.getElementById('notificationsModal');
    var notificationsBtn = document.querySelector('.btn-outline-light[data-bs-toggle="modal"]');
    var notificationsContent = document.getElementById('notificationsContent');
    var notificationsLoading = document.getElementById('notificationsLoading');
    var noNotifications = document.getElementById('noNotifications');
    var notificationsError = document.getElementById('notificationsError');
    var unreadBadge = document.getElementById('unreadBadge');
    var markAllReadBtn = document.getElementById('markAllRead');
    var refreshBtn = document.getElementById('refreshNotifications');

    // Show notification count badge on navbar button
    function updateNotificationBadge(count) {
        if (notificationsBtn) {
            let existingBadge = notificationsBtn.querySelector('.badge');
            if (existingBadge) {
                existingBadge.remove();
            }
            
            if (count > 0) {
                let badge = document.createElement('span');
                badge.className = 'badge bg-danger position-absolute top-0 start-100 translate-middle';
                badge.style.fontSize = '0.7rem';
                badge.textContent = count > 99 ? '99+' : count;
                notificationsBtn.style.position = 'relative';
                notificationsBtn.appendChild(badge);
            }
        }
    }

    // Get notification type color class
    function getTypeColorClass(type) {
        switch (type) {
            case 'success': return 'text-success';
            case 'warning': return 'text-warning';
            case 'danger': return 'text-danger';
            default: return 'text-primary';
        }
    }

    // Create notification HTML
    function createNotificationHTML(notification) {
        const isUnread = !notification.is_read;
        const unreadClass = isUnread ? 'border-start border-primary border-3' : '';
        const unreadBg = isUnread ? 'bg-light' : '';
        
        return `
            <div class="list-group-item d-flex align-items-start ${unreadClass} ${unreadBg}" data-notification-id="${notification.id}">
                <div class="me-3">
                    <i class="bi ${notification.icon} ${getTypeColorClass(notification.type)} fs-5"></i>
                </div>
                <div class="flex-grow-1">
                    <h6 class="mb-1 ${isUnread ? 'fw-bold' : ''}">${escapeHtml(notification.title)}</h6>
                    <p class="mb-1 text-muted">${escapeHtml(notification.message)}</p>
                    <small class="text-muted">${notification.time_ago}</small>
                </div>
                <div class="ms-2 d-flex flex-column gap-1">
                    ${isUnread ? `
                        <button type="button" class="btn btn-outline-primary btn-sm mark-read-btn" 
                                data-id="${notification.id}" title="Mark as read">
                            <i class="bi bi-check"></i>
                        </button>
                    ` : ''}
                    <button type="button" class="btn btn-outline-danger btn-sm delete-btn" 
                            data-id="${notification.id}" title="Delete notification">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>
            </div>
        `;
    }

    // Escape HTML to prevent XSS
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Determine if this is a staff or student page
    function getNotificationEndpoint() {
        const currentPath = window.location.pathname;
        if (currentPath.includes('/staff/')) {
            return '/enrollmentsystem/action/staff/notifications.php';
        } else {
            return '/enrollmentsystem/action/student/notifications.php';
        }
    }

    // Load notifications
    function loadNotifications() {
        showLoading();
        
        fetch(getNotificationEndpoint() + '?action=fetch')
            .then(response => response.json())
            .then(data => {
                hideLoading();
                
                if (data.success) {
                    displayNotifications(data.notifications);
                    updateBadges(data.unread_count);
                } else {
                    showError(data.message || 'Failed to load notifications');
                }
            })
            .catch(error => {
                hideLoading();
                showError('Network error occurred');
                console.error('Error:', error);
            });
    }

    // Display notifications
    function displayNotifications(notifications) {
        if (notifications.length === 0) {
            showNoNotifications();
            return;
        }

        let html = '';
        notifications.forEach(notification => {
            html += createNotificationHTML(notification);
        });
        
        notificationsContent.innerHTML = html;
        showContent();
        
        // Add event listeners to buttons
        addNotificationEventListeners();
    }

    // Add event listeners to notification buttons
    function addNotificationEventListeners() {
        // Mark as read buttons
        document.querySelectorAll('.mark-read-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                markAsRead(id);
            });
        });

        // Delete buttons
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                deleteNotification(id);
            });
        });
    }

    // Mark notification as read
    function markAsRead(id) {
        const endpoint = getNotificationEndpoint();
        const isStudent = endpoint.includes('/student/');
        fetch(endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: isStudent ? `action=mark_read&id=${id}` : `action=mark_read&notification_id=${id}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                loadNotifications(); // Reload to update UI
            } else {
                showAlert('Failed to mark notification as read', 'danger');
            }
        })
        .catch(error => {
            showAlert('Error occurred', 'danger');
            console.error('Error:', error);
        });
    }

    // Delete notification
    function deleteNotification(id) {
        if (confirm('Are you sure you want to delete this notification?')) {
            const endpoint = getNotificationEndpoint();
            const isStudent = endpoint.includes('/student/');
            fetch(endpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: isStudent ? `action=delete&id=${id}` : `action=delete&notification_id=${id}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    loadNotifications(); // Reload to update UI
                } else {
                    showAlert('Failed to delete notification', 'danger');
                }
            })
            .catch(error => {
                showAlert('Error occurred', 'danger');
                console.error('Error:', error);
            });
        }
    }

    // Mark all as read
    function markAllAsRead() {
        fetch(getNotificationEndpoint(), {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=mark_all_read'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                loadNotifications(); // Reload to update UI
                showAlert(`${data.marked_count} notifications marked as read`, 'success');
            } else {
                showAlert('Failed to mark all notifications as read', 'danger');
            }
        })
        .catch(error => {
            showAlert('Error occurred', 'danger');
            console.error('Error:', error);
        });
    }

    // Update badges and buttons
    function updateBadges(unreadCount) {
        updateNotificationBadge(unreadCount);
        
        if (unreadBadge) {
            if (unreadCount > 0) {
                unreadBadge.textContent = unreadCount;
                unreadBadge.style.display = 'inline';
            } else {
                unreadBadge.style.display = 'none';
            }
        }
        
        if (markAllReadBtn) {
            markAllReadBtn.style.display = unreadCount > 0 ? 'inline-block' : 'none';
        }
    }

    // Show/hide different states
    function showLoading() {
        notificationsLoading.style.display = 'block';
        notificationsContent.style.display = 'none';
        noNotifications.style.display = 'none';
        notificationsError.style.display = 'none';
    }

    function hideLoading() {
        notificationsLoading.style.display = 'none';
    }

    function showContent() {
        notificationsContent.style.display = 'block';
        noNotifications.style.display = 'none';
        notificationsError.style.display = 'none';
    }

    function showNoNotifications() {
        notificationsContent.style.display = 'none';
        noNotifications.style.display = 'block';
        notificationsError.style.display = 'none';
    }

    function showError(message) {
        notificationsContent.style.display = 'none';
        noNotifications.style.display = 'none';
        notificationsError.style.display = 'block';
        notificationsError.querySelector('span').textContent = message;
    }

    // Show alert message
    function showAlert(message, type = 'info') {
        // Create temporary alert
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
        alertDiv.style.top = '20px';
        alertDiv.style.right = '20px';
        alertDiv.style.zIndex = '9999';
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(alertDiv);
        
        // Auto remove after 3 seconds
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.remove();
            }
        }, 3000);
    }

    // Event listeners
    if (notificationsModal) {
        // Load notifications when modal is shown
        notificationsModal.addEventListener('show.bs.modal', function() {
            loadNotifications();
        });

        // Remove focus when modal is hidden
        notificationsModal.addEventListener('hidden.bs.modal', function() {
            if (notificationsBtn) {
                notificationsBtn.blur();
                document.body.focus();
            }
        });
    }

    // Mark all as read button
    if (markAllReadBtn) {
        markAllReadBtn.addEventListener('click', markAllAsRead);
    }

    // Refresh button
    if (refreshBtn) {
        refreshBtn.addEventListener('click', loadNotifications);
    }

    // Load notification count on page load
    if (notificationsBtn) {
        fetch(getNotificationEndpoint() + '?action=fetch')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    updateNotificationBadge(data.unread_count);
                }
            })
            .catch(error => {
                console.error('Error loading notification count:', error);
            });
    }
});