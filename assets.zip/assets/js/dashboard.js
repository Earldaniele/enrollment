// Dashboard dynamic content loader
let currentStudent = null;

// Load student information
async function loadStudentInfo() {
    try {
        // Call backend to get current logged-in user's info
        // No need to pass student_id - backend will determine from session
        const response = await fetch(`/enrollmentsystem/action/student/get_student_info.php`);
        const result = await response.json();
        
        console.log('API Response:', result);
        
        if (result.success && result.data) {
            currentStudent = result.data;
            updateDashboardUI();
        } else if (result.data) {
            // Even if not success, if we have data, use it
            currentStudent = result.data;
            updateDashboardUI();
        } else {
            console.error('Failed to load student info:', result.message);
            showNotRegisteredUI();
        }
        
    } catch (error) {
        console.error('Error loading student info:', error);
        showNotRegisteredUI();
    }
}

// Update dashboard UI with student information
function updateDashboardUI() {
    if (!currentStudent) {
        console.log('No current student data available');
        showNotRegisteredUI();
        return;
    }
    
    console.log('Updating dashboard with student data:', currentStudent);
    
    // Format name as "Lastname, Firstname MiddleInitial."
    let formattedName = '';
    if (currentStudent.full_name && currentStudent.full_name !== 'Not Registered') {
        formattedName = currentStudent.full_name;
    } else if (currentStudent.last_name && currentStudent.first_name) {
        // Use the individual name parts from the database
        const lastName = currentStudent.last_name || '';
        const firstName = currentStudent.first_name || '';
        const middleName = currentStudent.middle_name || '';
        
        // Get middle initial
        const middleInitial = middleName ? middleName.charAt(0).toUpperCase() + '.' : '';
        formattedName = `${lastName}, ${firstName} ${middleInitial}`.trim();
    } else {
        formattedName = 'Student';
    }
    
    console.log('Formatted name:', formattedName);
    
    // Update welcome message
    const welcomeMessage = document.getElementById('welcomeMessage');
    if (welcomeMessage) {
        welcomeMessage.textContent = `Welcome, ${formattedName}`;
    }
    
    // Update student ID section
    const studentIdSection = document.getElementById('studentIdSection');
    if (studentIdSection) {
        if (currentStudent.is_approved && currentStudent.student_id) {
            studentIdSection.innerHTML = `
                <p class="text-muted mb-0">
                    <strong>Student ID: </strong>
                    <span class="text-primary fw-bold">${currentStudent.student_id}</span>
                </p>
            `;
        } else {
            studentIdSection.innerHTML = `
                <p class="text-warning mb-0">
                    <i class="bi bi-clock-history me-1"></i>
                    <strong>Student ID will be assigned after registration approval</strong>
                </p>
            `;
        }
    }
    
    // Update registration status
    const statusSection = document.getElementById('registrationStatus');
    if (statusSection) {
        let statusHTML = '';
        
        switch (currentStudent.status) {
            case 'approved':
                statusHTML = `
                    <div class="alert alert-success py-2 mb-0">
                        <i class="bi bi-check-circle me-1"></i>
                        <strong>Registration Status: </strong>Approved
                        <small class="ms-2">• Course: ${currentStudent.course}</small>
                    </div>
                `;
                break;
                
            case 'pending':
                statusHTML = `
                    <div class="alert alert-warning py-2 mb-0">
                        <i class="bi bi-hourglass-split me-1"></i>
                        <strong>Registration Status: </strong>Pending Review
                        <small class="ms-2">• Your application is being processed</small>
                    </div>
                `;
                break;
                
            case 'rejected':
                statusHTML = `
                    <div class="alert alert-danger py-2 mb-0">
                        <i class="bi bi-x-circle me-1"></i>
                        <strong>Registration Status: </strong>Rejected
                        <small class="ms-2">• Please contact admissions office</small>
                    </div>
                `;
                break;
                
            default:
                statusHTML = `
                    <div class="alert alert-info py-2 mb-0">
                        <i class="bi bi-info-circle me-1"></i>
                        <strong>Registration Status: </strong>Not Registered
                        <small class="ms-2">• Complete your college registration to get started</small>
                    </div>
                `;
        }
        
        statusSection.innerHTML = statusHTML;
    }
    
    console.log('Dashboard updated with student info:', currentStudent);
}

// Show guest UI when no student data
function showGuestUI() {
    const welcomeMessage = document.getElementById('welcomeMessage');
    if (welcomeMessage) {
        welcomeMessage.textContent = 'Welcome, Guest!';
    }
    
    const studentIdSection = document.getElementById('studentIdSection');
    if (studentIdSection) {
        studentIdSection.innerHTML = `
            <p class="text-info mb-0">
                <i class="bi bi-person-plus me-1"></i>
                <strong>Please complete your registration to get a Student ID</strong>
            </p>
        `;
    }
    
    const statusSection = document.getElementById('registrationStatus');
    if (statusSection) {
        statusSection.innerHTML = `
            <div class="alert alert-info py-2 mb-0">
                <i class="bi bi-clipboard-check me-1"></i>
                <strong>Get Started: </strong>Complete your college registration form
                <small class="ms-2">• Click "Start Registration" to begin</small>
            </div>
        `;
    }
}

// Show UI for users who haven't registered yet
function showNotRegisteredUI() {
    const welcomeMessage = document.getElementById('welcomeMessage');
    const studentId = document.getElementById('studentId');
    const registrationStatus = document.getElementById('registrationStatus');
    
    if (welcomeMessage) {
        welcomeMessage.textContent = 'Welcome, Student';
    }
    
    if (studentId) {
        studentId.textContent = 'Not Registered';
    }
    
    if (registrationStatus) {
        registrationStatus.innerHTML = `
            <div class="alert alert-warning py-2 mb-0">
                <i class="bi bi-exclamation-triangle me-1"></i>
                <strong>Registration Required: </strong>Please complete your college registration first
                <small class="ms-2">• <a href="college-registration.php" class="text-decoration-none">Click here to register</a></small>
            </div>
        `;
    }
}

// Update queue management to use current student ID
function getCurrentStudentId() {
    return currentStudent?.student_id || null;
}

// Load current queues for the student
async function loadCurrentQueues() {
    try {
        console.log('Loading current queues...');
        
        // Show loading state
        const container = document.getElementById('currentQueuesContainer');
        if (container) {
            container.innerHTML = `
                <div class="text-center py-3">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-2">Loading your current queue status...</p>
                </div>
            `;
        }
        
        const response = await fetch('/enrollmentsystem/action/student/check_queue_status.php');
        console.log('Response received:', response);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        console.log('Queue data:', result);
        
        if (!container) {
            console.error('currentQueuesContainer not found');
            return;
        }
        
        if (result.success && result.queues && result.queues.length > 0) {
            // Use the simple queue layout from queue-management.js for consistency
            let html = '';
            
            result.queues.forEach(queue => {
                // Calculate time display based on status
                let timeDisplay = '';
                let timeLabel = '';
                let statusBadge = '';
                
                // Add time_remaining_seconds to queue for use in countdown timer
                if (queue.status === 'ready' && queue.expires_at) {
                    // Show countdown for ready tickets (2-minute timer)
                    const expiresAt = new Date(queue.expires_at).getTime();
                    const now = new Date().getTime();
                    const timeRemainingSeconds = Math.max(0, Math.floor((expiresAt - now) / 1000));
                    queue.time_remaining_seconds = timeRemainingSeconds;
                    timeDisplay = formatTime(timeRemainingSeconds);
                    timeLabel = 'Time Remaining';
                    statusBadge = '<span class="badge bg-primary"><i class="bi bi-bell me-1"></i>Ready - Please Proceed</span>';
                } else if (queue.status === 'in_progress') {
                    // Show countdown for in_progress tickets
                    const expiresAt = new Date(queue.expires_at).getTime();
                    const now = new Date().getTime();
                    const timeRemainingSeconds = Math.max(0, Math.floor((expiresAt - now) / 1000));
                    queue.time_remaining_seconds = timeRemainingSeconds;
                    timeDisplay = formatTime(timeRemainingSeconds);
                    timeLabel = 'Time Remaining';
                    statusBadge = '<span class="badge bg-success"><i class="bi bi-person-check me-1"></i>Being Served</span>';
                } else if (queue.status === 'waiting') {
                    // Show position in queue for waiting tickets
                    timeDisplay = 'Waiting...';
                    timeLabel = 'Queue Status';
                    statusBadge = '<span class="badge bg-warning text-dark"><i class="bi bi-clock me-1"></i>Waiting</span>';
                } else if (queue.status === 'completed') {
                    timeDisplay = 'Completed';
                    timeLabel = 'Status';
                    statusBadge = '<span class="badge bg-info"><i class="bi bi-check-circle me-1"></i>Completed</span>';
                } else if (queue.status === 'cancelled') {
                    timeDisplay = 'Cancelled';
                    timeLabel = 'Status';
                    statusBadge = '<span class="badge bg-danger"><i class="bi bi-x-circle me-1"></i>Cancelled</span>';
                } else if (queue.status === 'expired') {
                    timeDisplay = 'Expired';
                    timeLabel = 'Status';
                    statusBadge = '<span class="badge bg-secondary"><i class="bi bi-hourglass-bottom me-1"></i>Expired</span>';
                } else {
                    timeDisplay = 'N/A';
                    timeLabel = 'Status';
                    statusBadge = '<span class="badge bg-secondary">Unknown</span>';
                }
                
                const createdTime = new Date(queue.created_at).toLocaleString();
                const expiresTime = queue.expires_at ? new Date(queue.expires_at).toLocaleString() : 'When called to counter';
                
                // Determine status-specific styling
                let statusClass = '';
                let statusBg = '';
                
                switch(queue.status) {
                    case 'ready':
                        statusClass = 'status-ready';
                        statusBg = 'bg-primary bg-opacity-10';
                        break;
                    case 'in_progress':
                        statusClass = 'status-in-progress';
                        statusBg = 'bg-success bg-opacity-10';
                        break;
                    case 'waiting':
                        statusClass = 'status-waiting';
                        statusBg = 'bg-warning bg-opacity-10';
                        break;
                    default:
                        statusClass = '';
                        statusBg = 'bg-light';
                }
                
                html += `
                    <div class="queue-ticket-card border rounded p-3 mb-3 ${statusClass} ${statusBg}">
                        <div class="row align-items-center">
                            <div class="col-md-3 text-center">
                                <div class="display-6 fw-bold text-success">${queue.queue_number}</div>
                                <small class="text-muted">Queue Number</small>
                            </div>
                            <div class="col-md-4">
                                <h6 class="mb-1 text-success">${queue.department}</h6>
                                <p class="mb-0 small text-muted">Department</p>
                                ${statusBadge}
                            </div>
                            <div class="col-md-3 text-center">
                                <div class="h5 fw-bold text-success" id="currentQueueCountdown-${queue.id}">${timeDisplay}</div>
                                <small class="text-muted">${timeLabel}</small>
                            </div>
                            <div class="col-md-2 text-center">
                                <div class="d-grid gap-1">
                                    ${queue.status === 'ready' ? `
                                    <button class="btn btn-primary btn-sm mb-1 qr-code-btn" data-ticket-id="${queue.id}" data-queue-number="${queue.queue_number}" data-qr-data="${queue.qr_data || ''}">
                                        <i class="bi bi-qr-code me-1"></i>View QR Code
                                    </button>
                                    <div class="small text-warning mb-1">
                                        <i class="bi bi-clock me-1"></i>2 min to scan
                                    </div>
                                    ` : ''}
                                    ${queue.status === 'in_progress' ? `
                                    <div class="alert alert-success py-1 mb-1 small">
                                        <i class="bi bi-person-check me-1"></i>Being Served
                                    </div>
                                    ` : ''}
                                    ${queue.status === 'waiting' ? `
                                    <div class="text-muted small mb-1">
                                        <i class="bi bi-clock me-1"></i>Waiting in queue
                                    </div>
                                    ` : ''}
                                    ${['waiting', 'ready'].includes(queue.status) ? `
                                    <button class="btn btn-outline-danger btn-sm" onclick="cancelQueueFromStatus('${queue.id}')">
                                        <i class="bi bi-x-circle me-1"></i>Cancel
                                    </button>
                                    ` : ''}
                                </div>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-12">
                                <div class="alert alert-info py-2 mb-0">
                                    <i class="bi bi-info-circle me-1"></i>
                                    <small><strong>Created:</strong> ${createdTime} | 
                                    <strong>QR Code Valid:</strong> ${expiresTime}</small>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            });
            
            container.innerHTML = html;
            
            // Store current queues globally for QR code modal access
            window.currentQueues = result.queues;
            
            // Start countdown timers for real-time updates
            startCountdownTimers(result.queues);
            
            // Add event listeners to QR code buttons
            addQRCodeButtonListeners();
            
        } else if (result.success && (!result.queues || result.queues.length === 0)) {
            // No current queues
            container.innerHTML = `
                <div class="text-center text-muted py-4">
                    <i class="bi bi-clock-history display-4 mb-3"></i>
                    <h6>No Active Queue Tickets</h6>
                    <p class="mb-0">You don't have any pending queue tickets.</p>
                </div>
            `;
        } else {
            // API returned error
            container.innerHTML = `
                <div class="text-center text-warning py-4">
                    <i class="bi bi-info-circle display-4 mb-3"></i>
                    <h6>Unable to Load Queue Status</h6>
                    <p class="mb-0">${result.message || 'Please try again later.'}</p>
                    <button class="btn btn-outline-primary btn-sm mt-2" onclick="loadCurrentQueues()">
                        <i class="bi bi-arrow-clockwise"></i> Retry
                    </button>
                </div>
            `;
        }
        
    } catch (error) {
        console.error('Error loading current queues:', error);
        console.error('Error details:', error.message, error.stack);
        document.getElementById('currentQueuesContainer').innerHTML = `
            <div class="text-center text-danger py-3">
                <i class="bi bi-exclamation-triangle display-4 mb-3"></i>
                <p>Failed to load queue status</p>
                <small class="text-muted">Check console for details</small>
                <br>
                <button class="btn btn-sm btn-outline-primary mt-2" onclick="loadCurrentQueues()">
                    <i class="bi bi-arrow-clockwise"></i> Retry
                </button>
            </div>
        `;
    }
}

// Check if QRCode library is loaded, if not, load it dynamically
function ensureQRCodeLibraryLoaded() {
    return new Promise((resolve, reject) => {
        if (typeof QRCode !== 'undefined') {
            // Library already loaded
            console.log('QRCode library already loaded');
            resolve();
            return;
        }
        
        console.log('QRCode library not found, loading from local path...');
        
        // Load local QRCode library from assets/js
        const script = document.createElement('script');
        script.src = '/enrollmentsystem/assets/js/qrcode.min.js';
        script.onload = () => {
            console.log('QRCode library loaded successfully from local path');
            resolve();
        };
        script.onerror = (error) => {
            console.error('Failed to load local QRCode library:', error);
            reject(new Error('Failed to load QRCode library from local path'));
        };
        
        document.head.appendChild(script);
    });
}

// Show QR Code modal
async function showQRCodeModal(ticketId, queueNumber, qrData) {
    // Ensure QRCode library is loaded
    try {
        await ensureQRCodeLibraryLoaded();
    } catch (error) {
        console.error('QR Code library could not be loaded:', error);
        // Show modal anyway, but with error message
        const qrModal = new bootstrap.Modal(document.getElementById('qrCodeModal'));
        qrModal.show();
        
        const qrContainer = document.getElementById('qrCodeContainer');
        if (qrContainer) {
            showQRCodeError(qrContainer, 'QR Code library could not be loaded. Please try again later.');
        }
        return;
    }
    
    console.log('Opening QR Code modal for ticket:', ticketId, 'Queue:', queueNumber, 'QR Data:', qrData);
    console.log('QR Data type:', typeof qrData, 'Length:', qrData ? qrData.length : 0);
    console.log('QR Data raw:', JSON.stringify(qrData));
    
    // Update the ticket number
    const ticketNumberEl = document.getElementById('qrCodeTicketNumber');
    if (ticketNumberEl) {
        ticketNumberEl.textContent = queueNumber;
    }
    
    // Update additional information fields
    const departmentEl = document.getElementById('qrCodeDepartment');
    const studentIdEl = document.getElementById('qrCodeStudentId');
    
    if (departmentEl) {
        // Try to get department from current queue data
        const currentQueues = window.currentQueues || [];
        const currentQueue = currentQueues.find(q => q.id == ticketId);
        if (currentQueue && currentQueue.department) {
            departmentEl.textContent = currentQueue.department;
        } else {
            departmentEl.textContent = 'N/A';
        }
    }
    
    if (studentIdEl) {
        const studentId = getCurrentStudentId ? getCurrentStudentId() : 'N/A';
        studentIdEl.textContent = studentId;
    }
    
    // Generate QR code
    const qrContainer = document.getElementById('qrCodeContainer');
    if (qrContainer) {
        qrContainer.innerHTML = ''; // Clear previous QR code
        
        // Check if QRCode library is available
        if (typeof QRCode !== 'undefined') {
            try {
                // Prepare QR code data - if qrData is not provided or malformed, create a default structure
                let qrCodeText = qrData;
                
                // Check if qrData is valid and not malformed
                if (!qrCodeText || qrCodeText === '{' || qrCodeText === '}' || qrCodeText.trim().length < 2) {
                    // Create a simple URL-based QR code format for easier scanning
                    const studentId = getCurrentStudentId ? getCurrentStudentId() : 'STUDENT';
                    qrCodeText = `http://${window.location.hostname}/enrollmentsystem/scan.php?s=${studentId}&q=${ticketId}&n=${queueNumber}`;
                } else {
                    // If qrData is provided, try to simplify it for better scanning
                    try {
                        if (typeof qrCodeText === 'string') {
                            // Check if it's already a URL
                            if (qrCodeText.startsWith('http')) {
                                // Use as-is, it's already a URL
                            } else {
                                // Try to parse as JSON, if it fails, create a URL format
                                try {
                                    const parsed = JSON.parse(qrCodeText);
                                    // Convert to URL format for better scanning
                                    const studentId = parsed.student_id || (getCurrentStudentId ? getCurrentStudentId() : 'STUDENT');
                                    qrCodeText = `http://${window.location.hostname}/enrollmentsystem/scan.php?s=${studentId}&q=${parsed.ticket_id || ticketId}&n=${parsed.queue_number || queueNumber}`;
                                } catch (parseError) {
                                    console.warn('Invalid JSON in qr_data, creating URL format:', parseError);
                                    // Create a URL format
                                    const studentId = getCurrentStudentId ? getCurrentStudentId() : 'STUDENT';
                                    qrCodeText = `http://${window.location.hostname}/enrollmentsystem/scan.php?s=${studentId}&q=${ticketId}&n=${queueNumber}`;
                                }
                            }
                        } else if (typeof qrCodeText === 'object') {
                            // Convert object to URL format for easier scanning
                            const studentId = qrCodeText.student_id || (getCurrentStudentId ? getCurrentStudentId() : 'STUDENT');
                            qrCodeText = `http://${window.location.hostname}/enrollmentsystem/scan.php?s=${studentId}&q=${qrCodeText.ticket_id || ticketId}&n=${qrCodeText.queue_number || queueNumber}`;
                        }
                    } catch (error) {
                        console.warn('Error processing QR data, using URL format fallback:', error);
                        const studentId = getCurrentStudentId ? getCurrentStudentId() : 'STUDENT';
                        qrCodeText = `http://${window.location.hostname}/enrollmentsystem/scan.php?s=${studentId}&q=${ticketId}&n=${queueNumber}`;
                    }
                }
                
                console.log('Generating QR code with data:', qrCodeText);
                
                // Generate new QR code with optimal scanning parameters
                new QRCode(qrContainer, {
                    text: qrCodeText,
                    width: 250,  // Size for optimal scanning
                    height: 250, 
                    colorDark: "#000000", // Pure black for optimal scanning
                    colorLight: "#ffffff", // Pure white background
                    correctLevel: QRCode.CorrectLevel.L || 1, // Level L for less density and better scanning
                    margin: 4 // Standard margin for better scanning by mobile devices
                });
                
                // Add custom styling to the generated QR code
                const qrCanvas = qrContainer.querySelector('canvas');
                if (qrCanvas) {
                    qrCanvas.style.borderRadius = '12px';
                    qrCanvas.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
                    qrCanvas.style.border = '3px solid #253475';
                    qrCanvas.style.width = '100%';
                    qrCanvas.style.height = 'auto';
                    qrCanvas.style.maxWidth = '300px';
                }
                
            } catch (error) {
                console.error('Error generating QR code:', error);
                showQRCodeError(qrContainer, 'Error generating QR code');
            }
        } else {
            console.warn('QRCode library not available, showing enhanced placeholder');
            showQRCodePlaceholder(qrContainer, queueNumber);
        }
    }
    
    // Show the modal
    const qrModal = new bootstrap.Modal(document.getElementById('qrCodeModal'));
    qrModal.show();
}

// Show QR Code placeholder when library is not available
function showQRCodePlaceholder(container, queueNumber) {
    container.innerHTML = `
        <div class="qr-placeholder-container w-100">
            <div class="qr-placeholder py-4">
                <i class="bi bi-qr-code display-1 text-primary mb-3"></i>
            </div>
        </div>
    `;
}

// Show QR Code error
function showQRCodeError(container, message) {
    container.innerHTML = `
        <div class="qr-error-container w-100">
            <div class="alert alert-danger text-center py-4">
                <i class="bi bi-exclamation-triangle display-6 text-danger mb-3"></i>
                <h6 class="text-danger">QR Code Error</h6>
                <p class="mb-0 small">${message}</p>
            </div>
        </div>
    `;
}

// Function to download QR code
function downloadQRCode() {
    const qrCanvas = document.querySelector('#qrCodeContainer canvas');
    if (!qrCanvas) {
        console.error('No QR code canvas found');
        return;
    }
    
    try {
        // Get student ID and queue number for filename
        const studentId = document.getElementById('qrCodeStudentId')?.textContent || 'student';
        const queueNumber = document.getElementById('qrCodeTicketNumber')?.textContent || 'queue';
        
        // Create a temporary link element
        const link = document.createElement('a');
        link.download = `queue-ticket-${studentId}-${queueNumber}.png`;
        link.href = qrCanvas.toDataURL('image/png').replace('image/png', 'image/octet-stream');
        
        // Trigger the download
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        // Show success message
        Swal.fire({
            title: 'QR Code Downloaded',
            text: 'The QR code has been saved to your device.',
            icon: 'success',
            timer: 2000,
            showConfirmButton: false
        });
    } catch (error) {
        console.error('Error downloading QR code:', error);
        Swal.fire({
            title: 'Download Failed',
            text: 'Could not download the QR code. Please try again.',
            icon: 'error'
        });
    }
}

// Helper functions
function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

function getStatusBadge(status) {
    switch(status.toLowerCase()) {
        case 'waiting':
            return '<span class="badge bg-warning text-dark"><i class="bi bi-clock me-1"></i>Waiting</span>';
        case 'ready':
            return '<span class="badge bg-primary"><i class="bi bi-bell me-1"></i>Ready - Please Proceed</span>';
        case 'in_progress':
            return '<span class="badge bg-success"><i class="bi bi-person-check me-1"></i>Being Served</span>';
        case 'completed':
            return '<span class="badge bg-info"><i class="bi bi-check-circle me-1"></i>Completed</span>';
        case 'cancelled':
            return '<span class="badge bg-danger"><i class="bi bi-x-circle me-1"></i>Cancelled</span>';
        case 'expired':
            return '<span class="badge bg-secondary"><i class="bi bi-hourglass-bottom me-1"></i>Expired</span>';
        default:
            return '<span class="badge bg-secondary">Unknown</span>';
    }
}

function getDepartmentIcon(department) {
    switch(department.toLowerCase()) {
        case 'registrar':
            return 'bi bi-file-earmark-text';
        case 'treasury':
            return 'bi bi-cash-coin';
        case 'enrollment':
            return 'bi bi-people';
        default:
            return 'bi bi-building';
    }
}

function formatDateTime(dateTime) {
    return new Date(dateTime).toLocaleString();
}

// Cancel queue function - use cancelQueueFromStatus instead for consistency
async function cancelQueue(queueId) {
    // If cancelQueueFromStatus is available, use it
    if (typeof cancelQueueFromStatus === 'function') {
        await cancelQueueFromStatus(queueId);
        return;
    }
    
    // Fallback to original implementation if cancelQueueFromStatus isn't available
    const result = await Swal.fire({
        title: 'Cancel Queue Ticket?',
        text: "Are you sure you want to cancel this queue ticket? This action cannot be undone.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#dc3545',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Yes, cancel it!',
        cancelButtonText: 'Keep ticket'
    });

    if (!result.isConfirmed) {
        return;
    }
    
    // Show loading state
    Swal.fire({
        title: 'Cancelling...',
        text: 'Please wait while we cancel your queue ticket.',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
    
    try {
        const response = await fetch('/enrollmentsystem/action/student/cancel_queue.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ ticket_id: queueId })
        });
        
        const responseData = await response.json();
        
        if (responseData.success) {
            // Reload queues to update display
            loadCurrentQueues();
            
            Swal.fire({
                title: 'Cancelled!',
                text: 'Your queue ticket has been cancelled successfully.',
                icon: 'success',
                confirmButtonColor: '#28a745',
                timer: 2000,
                timerProgressBar: true
            });
        } else {
            Swal.fire({
                title: 'Cancellation Failed',
                text: responseData.message || 'Unable to cancel your queue ticket. Please try again.',
                icon: 'error',
                confirmButtonColor: '#dc3545'
            });
        }
        
    } catch (error) {
        console.error('Error cancelling queue:', error);
        Swal.fire({
            title: 'Connection Error',
            text: 'Unable to connect to the server. Please check your internet connection and try again.',
            icon: 'error',
            confirmButtonColor: '#dc3545'
        });
    }
}

// Countdown timer function
let countdownIntervals = [];

function startCountdownTimers(queues) {
    // Clear existing intervals
    countdownIntervals.forEach(interval => clearInterval(interval));
    countdownIntervals = [];
    
    console.log('Starting countdown timers for', queues.length, 'queues');
    
    queues.forEach(queue => {
        const timerElement = document.getElementById(`currentQueueCountdown-${queue.id}`);
        if (!timerElement) {
            console.warn(`Timer element not found for queue ${queue.id}. Expected ID: currentQueueCountdown-${queue.id}`);
            return;
        }
        
        let timeLeft = 0;
        
        // Special handling for 'ready' status - always show the 2-minute timer
        if (queue.status === 'ready') {
            if (queue.expires_timestamp) {
                // Calculate time remaining based on the expiration timestamp to prevent timer reset on refresh
                const now = Math.floor(Date.now() / 1000);
                timeLeft = Math.max(0, queue.expires_timestamp - now);
                console.log(`Ready ticket ${queue.id}: Timer from timestamp: ${timeLeft} seconds`);
            } else if (queue.time_remaining_seconds) {
                timeLeft = queue.time_remaining_seconds;
                console.log(`Ready ticket ${queue.id}: Timer from seconds: ${timeLeft} seconds`);
            } else {
                // Default to 2 minutes if no time data
                timeLeft = 120;
                console.log(`Ready ticket ${queue.id}: Using default timer: ${timeLeft} seconds`);
            }
        } else {
            // Regular handling for other status types
            timeLeft = queue.time_remaining_seconds || parseInt(timerElement.dataset.seconds) || 0;
            console.log(`Timer for queue ${queue.id}: ${timeLeft} seconds remaining`);
        }
        
        // For 'ready' status, always ensure we have a timer (even if timeLeft is 0)
        if (timeLeft > 0 || queue.status === 'ready') {
            // If it's a ready ticket with no valid timer, set to default 2 minutes
            if (queue.status === 'ready' && timeLeft <= 0) {
                timeLeft = 120;
                console.log(`Ready ticket ${queue.id}: Using default 2-minute timer`);
            }
            
            // Initial display update
            const minutes = Math.floor(timeLeft / 60);
            const seconds = timeLeft % 60;
            const initialDisplay = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            
            // Set initial color based on time
            if (timeLeft <= 30) {
                timerElement.innerHTML = `<span class="text-danger">${initialDisplay}</span>`;
                timerElement.className = "h4 fw-bold text-danger";
            } else if (timeLeft <= 60) {
                timerElement.innerHTML = `<span class="text-warning">${initialDisplay}</span>`;
                timerElement.className = "h4 fw-bold text-warning";
            } else {
                timerElement.innerHTML = `<span class="text-success">${initialDisplay}</span>`;
                timerElement.className = "h4 fw-bold text-success";
            }
            
            // Start the timer
            const interval = setInterval(() => {
                timeLeft--;
                
                if (timeLeft <= 0) {
                    clearInterval(interval);
                    timerElement.innerHTML = '<span class="text-danger">EXPIRED</span>';
                    timerElement.className = "h4 fw-bold text-danger";
                    
                    // Show a notification for expired tickets
                    Swal.fire({
                        title: 'Queue Expired',
                        text: 'Your queue ticket has expired because the time limit has passed.',
                        icon: 'warning',
                        confirmButtonColor: '#dc3545',
                        timer: 3000,
                        timerProgressBar: true
                    });
                    
                    // Reload queues to update status
                    setTimeout(() => loadCurrentQueues(), 1000);
                    return;
                }
                
                const minutes = Math.floor(timeLeft / 60);
                const seconds = timeLeft % 60;
                const timeDisplay = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
                
                // Change color based on time remaining
                if (timeLeft <= 30) { // Less than 30 seconds
                    timerElement.innerHTML = `<span class="text-danger">${timeDisplay}</span>`;
                    timerElement.className = "h4 fw-bold text-danger";
                } else if (timeLeft <= 60) { // Less than 1 minute
                    timerElement.innerHTML = `<span class="text-warning">${timeDisplay}</span>`;
                    timerElement.className = "h4 fw-bold text-warning";
                } else {
                    timerElement.innerHTML = `<span class="text-success">${timeDisplay}</span>`;
                    timerElement.className = "h4 fw-bold text-success";
                }
            }, 1000);
            
            countdownIntervals.push(interval);
        } else {
            // For any status other than 'ready' with no timer data
            timerElement.innerHTML = '<span class="text-muted">No time data</span>';
        }
    });
}

// Initialize dashboard on page load
document.addEventListener('DOMContentLoaded', function() {
    console.log('Dashboard initializing...');
    loadStudentInfo();
    loadCurrentQueues();
});

// Add event listeners to QR code buttons
function addQRCodeButtonListeners() {
    const qrButtons = document.querySelectorAll('.qr-code-btn');
    qrButtons.forEach(button => {
        button.addEventListener('click', async function() {
            try {
                // Show loading indicator
                Swal.fire({
                    title: 'Loading QR Code',
                    text: 'Please wait while we generate your QR code...',
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });
                
                const ticketId = this.getAttribute('data-ticket-id');
                const queueNumber = this.getAttribute('data-queue-number');
                const qrData = this.getAttribute('data-qr-data');
                
                // Show QR Code Modal (async function)
                await showQRCodeModal(ticketId, queueNumber, qrData);
                
                // Close loading indicator
                Swal.close();
            } catch (error) {
                console.error('Error displaying QR code:', error);
                Swal.fire({
                    title: 'QR Code Error',
                    text: 'There was a problem generating your QR code. Please try again.',
                    icon: 'error'
                });
            }
        });
    });
}

// Export for use in queue management
window.getCurrentStudentId = getCurrentStudentId;
