// Queue Management System
let countdownTimer = null;
let currentTicketId = null;

// Get current student ID from dashboard
function getCurrentStudentForQueue() {
    console.log('Getting current student ID for queue...');
    
    if (typeof getCurrentStudentId === 'function') {
        const studentId = getCurrentStudentId();
        console.log('Student ID from dashboard:', studentId);
        return studentId;
    }
    
    // Fallback - try to get from global variable or session
    if (window.currentStudent && window.currentStudent.student_id) {
        console.log('Student ID from window.currentStudent:', window.currentStudent.student_id);
        return window.currentStudent.student_id;
    }
    
    // Final fallback
    console.log('Using fallback student ID');
    return '2025-00001';
}

// Function to select department and close modal
function selectDepartmentAndClose(department) {
    console.log('Department selected:', department);
    
    // Show loading in modal
    showModalAlert('info', 'Processing your request...', true);
    
    // Proceed with getting queue number
    getQueueNumber(department);
}

// Get queue number function - Updated to use backend API
async function getQueueNumber(department) {
    console.log('Getting queue number for department:', department);
    
    try {
        // Show loading state
        showLoadingState();
        
        const requestBody = {
            department: department,
            student_id: getCurrentStudentForQueue()
        };
        
        console.log('Request body:', requestBody);
        
        const response = await fetch('../../action/student/get_queue.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(requestBody)
        });
        
        console.log('API Response status:', response.status);
        console.log('API Response headers:', response.headers);
        
        // Check if response is ok
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        // Get response text first to see what we're dealing with
        const responseText = await response.text();
        console.log('API Response text:', responseText);
        
        // Try to parse as JSON
        let result;
        try {
            result = JSON.parse(responseText);
        } catch (parseError) {
            console.error('JSON parse error:', parseError);
            console.error('Response text that failed to parse:', responseText);
            throw new Error('Invalid JSON response from server');
        }
        
        console.log('API Result:', result);
        
        if (result.success) {
            // Get the first queue from the queues array
            const queueData = result.queues && result.queues.length > 0 ? result.queues[0] : null;
            
            if (!queueData) {
                console.error('No queue data received. Result structure:', result);
                showModalAlert('danger', 'No queue data received from server. Please try again.');
                return;
            }
            
            // Log the actual queue data for debugging
            console.log('Queue data received:', queueData);
            
            // Use safe defaults for missing fields
            const ticketId = queueData.ticket_id || queueData.id || null;
            const queueNumber = queueData.queue_number || 'Unknown';
            
            if (ticketId) {
                currentTicketId = ticketId;
            }
            
            console.log('Processing queue with ticket ID:', ticketId, 'and queue number:', queueNumber);
            
            // Show success alert in modal
            showModalAlert('success', `Queue number ${queueNumber} generated successfully for ${department} department! When your number is called, you'll have 2 minutes to respond.`);
            
            // Store the ticket ID globally
            if (ticketId) {
                currentTicketId = ticketId;
            }
            
            // IMPORTANT: Immediately update the current queue status
            // First with the direct data we have
            updateCurrentQueueStatusDynamic(queueData, department);
            
            // Then refresh from the server to ensure consistency
            if (typeof loadCurrentQueues === 'function') {
                loadCurrentQueues();
            }
            
            // Reset button state
            resetButtonState();
            
        } else {
            console.error('API returned success: false', result);
            showModalAlert('danger', result.message || 'Failed to generate queue number. Please try again.');
        }
        
    } catch (error) {
        console.error('Error getting queue number:', error);
        console.error('Error stack:', error.stack);
        console.error('Error details:', {
            message: error.message,
            name: error.name,
            stack: error.stack
        });
        
        // Provide more specific error messages based on error type
        let errorMessage = 'Network error. Please check your connection and try again.';
        
        if (error.message.includes('queue data')) {
            errorMessage = 'Invalid response from server. Please try again.';
        } else if (error.message.includes('JSON')) {
            errorMessage = 'Server response format error. Please contact support.';
        } else if (error.message.includes('HTTP error')) {
            errorMessage = 'Server error. Please try again later.';
        }
        
        showModalAlert('danger', `Error: ${error.message || errorMessage}`);
        
        // Reset button state after error
        setTimeout(() => {
            resetButtonState();
        }, 100);
        
        // Don't close modal immediately on error, let user see the error message
        // After a delay, allow manual closure
        setTimeout(() => {
            hideModalAlert();
        }, 5000);
        
        // Don't reset queue state if the queue was actually created (error might be in processing response)
    }
}

// Generate QR Code
function generateQRCode(qrData) {
    const qrContainer = document.getElementById('qrcode');
    qrContainer.innerHTML = ''; // Clear previous QR code
    
    // Try to use QRCode library if available, otherwise show placeholder
    if (typeof QRCode !== 'undefined') {
        QRCode.toCanvas(qrData, { 
            width: 120, 
            height: 120,
            color: {
                dark: '#000000',
                light: '#FFFFFF'
            }
        }, function (error, canvas) {
            if (error) {
                console.error('QR Code generation error:', error);
                showQRPlaceholder(qrContainer);
            } else {
                canvas.style.borderRadius = '8px';
                canvas.style.border = '2px solid #dee2e6';
                qrContainer.appendChild(canvas);
            }
        });
    } else {
        console.warn('QRCode library not available, showing placeholder');
        showQRPlaceholder(qrContainer);
    }
}

// Show QR Code placeholder
function showQRPlaceholder(container) {
    container.innerHTML = `
        <div style="width: 120px; height: 120px; background: #f8f9fa; border: 2px dashed #dee2e6; 
             display: flex; align-items: center; justify-content: center; margin: 0 auto; border-radius: 8px;">
            <div class="text-center">
                <i class="bi bi-qr-code display-6 text-muted"></i>
                <br><small class="text-muted">QR Code</small>
            </div>
        </div>
    `;
}

// Start countdown timer - Updated to accept custom duration
function startCountdown(seconds = 120, elementId = 'currentQueueCountdown') { // Default 2 minutes for ticket expiration
    // Clear any existing countdown
    if (countdownTimer) {
        clearInterval(countdownTimer);
    }
    
    countdownTimer = setInterval(() => {
        seconds--;
        
        // Update the countdown display if the element exists
        const countdownElement = document.getElementById(elementId);
        if (countdownElement) {
            updateCountdownDisplay(seconds, countdownElement);
        } else {
            console.warn(`Timer element not found: ${elementId}`);
        }
        
        if (seconds <= 0) {
            clearInterval(countdownTimer);
            expireQueue();
        }
    }, 1000);
    
    // Initial display
    const countdownElement = document.getElementById(elementId);
    if (countdownElement) {
        updateCountdownDisplay(seconds, countdownElement);
    }
    console.log('Countdown started for', seconds, 'seconds');
}

// Update countdown display
function updateCountdownDisplay(seconds, element = null) {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    const display = `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    
    // Update countdown in current queue status section
    const countdownElement = element || document.getElementById('currentQueueCountdown');
    if (countdownElement) {
        countdownElement.textContent = display;
        
        // For 2-minute timer (ready state), use color coding to indicate urgency
        if (seconds <= 30) { // Last 30 seconds
            countdownElement.className = 'h4 fw-bold text-danger';
        } else if (seconds <= 60) { // Last minute
            countdownElement.className = 'h4 fw-bold text-warning';
        } else {
            countdownElement.className = 'h4 fw-bold text-success';
        }
    }
}

// Cancel queue function - Updated to use backend API
async function cancelQueue() {
    if (typeof Swal !== 'undefined') {
        const result = await Swal.fire({
            title: 'Cancel Queue?',
            text: 'Are you sure you want to cancel your queue ticket?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#dc3545',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Yes, cancel it',
            cancelButtonText: 'Keep queue'
        });
        
        if (result.isConfirmed) {
            await performCancelQueue();
        }
    } else {
        if (confirm('Are you sure you want to cancel your queue ticket?')) {
            await performCancelQueue();
        }
    }
}

// Perform actual queue cancellation
async function performCancelQueue(ticketId) {
    try {
        if (!ticketId) {
            console.error('Cancel queue error: No ticket ID provided');
            showErrorMessage('Cannot cancel queue: Ticket ID is missing');
            return;
        }
        
        const response = await fetch('../../action/student/cancel_queue.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                ticket_id: ticketId,
                student_id: getCurrentStudentForQueue()
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Clear countdown
            if (countdownTimer) {
                clearInterval(countdownTimer);
            }
            
            // Use loadCurrentQueues to update UI instead of direct state reset
            if (typeof loadCurrentQueues === 'function') {
                loadCurrentQueues();
            }
            
            // Show success message
            if (typeof Swal !== 'undefined') {
                Swal.fire({
                    title: 'Success!',
                    text: 'Queue ticket cancelled successfully.',
                    icon: 'success',
                    timer: 3000,
                    showConfirmButton: false
                });
            } else {
                alert('Queue ticket cancelled successfully.');
            }
        } else {
            showErrorMessage(result.message || 'Failed to cancel queue ticket');
        }
        
    } catch (error) {
        console.error('Error cancelling queue:', error);
        showErrorMessage('Network error. Please try again.');
    }
}

// Update ticket status to expired in the database
async function updateTicketStatusToExpired() {
    if (!currentTicketId) {
        console.error('Cannot expire ticket: No current ticket ID');
        return;
    }

    try {
        console.log('Updating ticket status to expired:', currentTicketId);
        
        const response = await fetch('../../action/student/cancel_queue.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                ticket_id: currentTicketId,
                student_id: getCurrentStudentForQueue(),
                status: 'expired'  // This will be ignored by current API but useful if API is updated
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            console.log('Ticket marked as expired successfully');
            // Reset currentTicketId since it's now expired
            currentTicketId = null;
        } else {
            console.error('Failed to update ticket status:', result.message);
        }
    } catch (error) {
        console.error('Error updating ticket status to expired:', error);
    }
}

// Show loading state
function showLoadingState() {
    // Only disable department buttons in the modal
    const departmentButtons = document.querySelectorAll('.department-btn');
    departmentButtons.forEach(btn => {
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Wait...';
    });
}

// Reset button state
function resetButtonState() {
    // Reset all department buttons in the modal
    const departmentButtons = document.querySelectorAll('.department-btn');
    departmentButtons.forEach(btn => {
        // Extract the original department name from the button's data attribute or onclick
        let deptName = btn.getAttribute('data-department');
        if (!deptName && btn.getAttribute('onclick')) {
            const onclickMatch = btn.getAttribute('onclick').match(/selectDepartmentAndClose\(['"]([^'"]+)['"]\)/);
            if (onclickMatch && onclickMatch[1]) {
                deptName = onclickMatch[1];
            }
        }
        
        // Default text if department name couldn't be extracted
        const buttonText = deptName ? `Select ${deptName}` : 'Select Department';
        
        btn.disabled = false;
        btn.innerHTML = buttonText;
    });
}

// Show success message
function showSuccessMessage(message) {
    if (typeof Swal !== 'undefined') {
        Swal.fire({
            title: 'Success!',
            text: message,
            icon: 'success',
            timer: 3000,
            showConfirmButton: false
        });
    } else {
        alert(message);
    }
}

// Show error message
function showErrorMessage(message) {
    if (typeof Swal !== 'undefined') {
        Swal.fire({
            title: 'Error!',
            text: message,
            icon: 'error',
            confirmButtonText: 'OK'
        });
    } else {
        alert('Error: ' + message);
    }
}

// Expire queue function
function expireQueue() {
    // First update the ticket status in the database
    updateTicketStatusToExpired();
    
    // Show expiration alert
    if (typeof Swal !== 'undefined') {
        Swal.fire({
            title: 'Queue Ticket Expired!',
            text: 'Your 2-minute response time has expired. Please get a new queue number to continue.',
            icon: 'warning',
            confirmButtonText: 'Get New Ticket'
        }).then(() => {
            // Use loadCurrentQueues to update UI instead of direct state reset
            if (typeof loadCurrentQueues === 'function') {
                loadCurrentQueues();
            }
        });
    } else {
        alert('Queue ticket expired! Your 2-minute response time has ended. Please get a new queue number.');
        // Use loadCurrentQueues to update UI instead of direct state reset
        if (typeof loadCurrentQueues === 'function') {
            loadCurrentQueues();
        }
    }
}

// Reset queue state
function resetQueueState() {
    // Clear any running timers
    if (countdownTimer) {
        clearInterval(countdownTimer);
        countdownTimer = null;
    }
    
    // Reset variables
    currentTicketId = null;
    
    // Update current queue status to show no active queues
    showNoActiveQueueState();
}

// Show modal alert function
function showModalAlert(type, message, showSpinner = false) {
    const alertContainer = document.getElementById('queueModalAlert');
    if (!alertContainer) return;
    
    let alertClass = '';
    let iconClass = '';
    
    switch(type) {
        case 'success':
            alertClass = 'alert-success';
            iconClass = 'bi-check-circle-fill';
            break;
        case 'danger':
            alertClass = 'alert-danger';
            iconClass = 'bi-exclamation-triangle-fill';
            break;
        case 'info':
            alertClass = 'alert-info';
            iconClass = 'bi-info-circle-fill';
            break;
        default:
            alertClass = 'alert-primary';
            iconClass = 'bi-info-circle-fill';
    }
    
    const spinnerHtml = showSpinner ? '<div class="spinner-border spinner-border-sm me-2" role="status"></div>' : `<i class="bi ${iconClass} me-2"></i>`;
    
    alertContainer.innerHTML = `
        <div class="alert ${alertClass} alert-dismissible fade show mb-0" role="alert">
            ${spinnerHtml}
            ${message}
        </div>
    `;
    alertContainer.style.display = 'block';
}

// Hide modal alert function
function hideModalAlert() {
    const alertContainer = document.getElementById('queueModalAlert');
    if (alertContainer) {
        alertContainer.style.display = 'none';
        alertContainer.innerHTML = '';
    }
}

// Update current queue status dynamically
function updateCurrentQueueStatusDynamic(queueData, department) {
    const container = document.getElementById('currentQueuesContainer');
    if (!container) {
        console.error('currentQueuesContainer not found');
        return;
    }
    
    console.log('Updating queue status with data:', queueData);
    
    // Get safe values with defaults - support both ticket_id and id fields
    const queueNumber = queueData.queue_number || 'Unknown';
    const ticketId = queueData.ticket_id || queueData.id || '';
    const departmentName = queueData.department || department || 'Unknown';
    const status = queueData.status || 'waiting';
    const createdTime = queueData.created_at ? new Date(queueData.created_at).toLocaleString() : new Date().toLocaleString();
    
    // Show loading state before updating
    container.innerHTML = `
        <div class="text-center py-3">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <p class="mt-2">Updating your queue status...</p>
        </div>
    `;
    
    // Calculate time display based on status
    let timeDisplay = '';
    let timeLabel = '';
    let statusBadge = '';
    let showTimer = false;
    
    switch(status) {
        case 'waiting':
            timeDisplay = 'Waiting...';
            timeLabel = 'Queue Status';
            statusBadge = '<span class="badge bg-warning text-dark"><i class="bi bi-clock me-1"></i>Waiting</span>';
            break;
        
        case 'ready':
            timeDisplay = '02:00';  // 2-minute countdown
            timeLabel = 'Time Remaining';
            statusBadge = '<span class="badge bg-success"><i class="bi bi-bell me-1"></i>Ready - Your Turn!</span>';
            showTimer = true;
            startCountdown(120);  // Start 2-minute timer
            break;
        
        case 'in_progress':
            timeDisplay = 'In Progress';
            timeLabel = 'Status';
            statusBadge = '<span class="badge bg-primary"><i class="bi bi-person-check me-1"></i>Being Processed</span>';
            break;
        
        case 'completed':
            timeDisplay = 'Completed';
            timeLabel = 'Status';
            statusBadge = '<span class="badge bg-success"><i class="bi bi-check-circle me-1"></i>Completed</span>';
            break;
        
        case 'cancelled':
            timeDisplay = 'Cancelled';
            timeLabel = 'Status';
            statusBadge = '<span class="badge bg-secondary"><i class="bi bi-x-circle me-1"></i>Cancelled</span>';
            break;
        
        case 'expired':
            timeDisplay = 'Expired';
            timeLabel = 'Status';
            statusBadge = '<span class="badge bg-danger"><i class="bi bi-exclamation-triangle me-1"></i>Expired</span>';
            break;
        
        default:
            timeDisplay = 'N/A';
            timeLabel = 'Status';
            statusBadge = '<span class="badge bg-secondary">Unknown</span>';
    }
    
    const expiresTime = queueData.expires_at ? new Date(queueData.expires_at).toLocaleString() : 'When called to counter';
    
    console.log('Queue display values:', {
        queueNumber,
        ticketId,
        departmentName,
        status,
        timeDisplay
    });
    
    // Set currentTicketId for later reference
    if (ticketId) {
        currentTicketId = ticketId;
    }
    
    // Use the first UI design as preferred
    container.innerHTML = `
        <div class="queue-ticket-card border rounded p-3 mb-3 border-success bg-light">
            <div class="row align-items-center">
                <div class="col-md-2 text-center">
                    <div class="display-6 fw-bold text-success">${queueNumber}</div>
                    <small class="text-muted">Queue Number</small>
                </div>
                <div class="col-md-3">
                    <h6 class="mb-1 text-success">${departmentName}</h6>
                    <p class="mb-0 small text-muted">Department</p>
                </div>
                <div class="col-md-3 text-center">
                    ${status === 'ready' ? `
                    <div class="timer-container">
                        <div class="h4 fw-bold text-danger" id="currentQueueCountdown">${timeDisplay}</div>
                        <small class="text-muted">Time Remaining</small>
                    </div>` : ``}
                </div>
                <div class="col-md-2 text-center">
                    ${statusBadge}
                    <div class="small text-muted mt-1">${timeLabel}</div>
                </div>
                <div class="col-md-2 text-center">
                    ${ticketId && (status === 'waiting' || status === 'ready') ? `
                    <div class="d-grid gap-1">
                        <button class="btn btn-outline-danger btn-sm" onclick="cancelQueueFromStatus('${ticketId}')">
                            <i class="bi bi-x-circle me-1"></i>Cancel
                        </button>
                    </div>
                    ` : `
                    <span class="text-muted small">${status === 'expired' ? 'Expired' : (status === 'completed' ? 'Completed' : 'Processing...')}</span>
                    `}
                </div>
            </div>
            <div class="row mt-2">
                <div class="col-12">
                    <div class="alert alert-info py-2 mb-0">
                        <i class="bi bi-info-circle me-1"></i>
                        <small><strong>Created:</strong> ${createdTime} | 
                        <strong>QR Code Valid:</strong> ${expiresTime}</small>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    console.log('Queue status updated successfully with preferred UI style');
}

// Show no active queue state
function showNoActiveQueueState() {
    const container = document.getElementById('currentQueuesContainer');
    if (!container) return;
    
    container.innerHTML = `
        <div class="text-center text-muted py-5">
            <i class="bi bi-clock-history display-4 mb-3"></i>
            <h6>No Active Queue Tickets</h6>
            <p class="mb-3">You don't have any pending queue tickets.</p>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#queueModal">
                <i class="bi bi-plus-circle me-1"></i>Get Queue Number
            </button>
        </div>
    `;
}

// Cancel queue from status section
async function cancelQueueFromStatus(ticketId) {
    if (!ticketId) {
        console.error('Cancel queue error: No ticket ID provided');
        showErrorMessage('Cannot cancel queue: Ticket ID is missing');
        return;
    }
    
    console.log('Cancelling queue with ticket ID:', ticketId);
    
    if (typeof Swal !== 'undefined') {
        const result = await Swal.fire({
            title: 'Cancel Queue Ticket?',
            text: 'Are you sure you want to cancel this queue ticket?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#dc3545',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Yes, cancel it',
            cancelButtonText: 'Keep queue'
        });
        
        if (result.isConfirmed) {
            await performCancelQueue(ticketId);
        }
    } else {
        if (confirm('Are you sure you want to cancel your queue ticket?')) {
            await performCancelQueue(ticketId);
        }
    }
}

// Removed the simulate serving function as it's no longer needed

// Format time helper function
function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    // Note: checkExistingQueue() was removed to avoid race conditions
    // Queue status is now handled entirely by loadCurrentQueues() in dashboard.js
    
    // Add event listener to clear modal alerts when modal opens
    const queueModal = document.getElementById('queueModal');
    if (queueModal) {
        queueModal.addEventListener('show.bs.modal', function () {
            hideModalAlert();
            resetButtonState(); // Ensure button is in correct state when modal opens
        });
    }
    
    // Add custom timer styles to head if not already present
    if (!document.getElementById('queue-timer-styles')) {
        const style = document.createElement('style');
        style.id = 'queue-timer-styles';
        style.textContent = `
            .timer-container {
                background-color: #f8f9fa;
                border: 2px solid #dc3545;
                border-radius: 8px;
                padding: 10px;
                box-shadow: 0 0 10px rgba(0,0,0,0.1);
                animation: pulse 1s infinite;
            }
            @keyframes pulse {
                0% { box-shadow: 0 0 0 0 rgba(220, 53, 69, 0.4); }
                70% { box-shadow: 0 0 0 10px rgba(220, 53, 69, 0); }
                100% { box-shadow: 0 0 0 0 rgba(220, 53, 69, 0); }
            }
        `;
        document.head.appendChild(style);
    }
    
    console.log('Queue Management System initialized with timer styles');
});
